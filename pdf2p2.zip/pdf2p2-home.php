<?php

function render_pdf2p2_home_page() {
    echo '<div class="wrap"><h1>pdf2p2 - Welcome Home!</h1>';
	echo '<div class="wrap">Add UI here to show some info about the project</p>';
	echo '<div class="wrap">Maybe a dashboard with some graphs :-) </p>';
}
