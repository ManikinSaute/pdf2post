<?php

function pdf2p2_render_bulk_import_page() {
    echo '<div class="wrap"><h1>pdf2p2 - Bulk Imports</h1>';
	echo '<div class="wrap">Add UI here to paste in a List of files to be processed</p>';
	echo '<div class="wrap">Add a UI to show progress</p>';
}
